
var X = "clown";
var Y = "Berlin";
var Z = "Jesus";
var N = "3";


function tellingFortunes() {
	var resultString = "You will be a " + X + " in " + Y + ", and married to " + Z + " with " + N + " kids."
	document.getElementById('fortune').innerHTML = resultString;
	return;
}

